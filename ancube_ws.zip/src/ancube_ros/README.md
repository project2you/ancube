# Ancube-X
Ancube-X is a mobile robot controller. 




## SET WIFI POWER SAVE OFF

    $ sudo iw dev wlan0 set power_save off
    $ sudo iw dev wlan0 get power_save




## Setup

1. roscd ancube_bringup/scripts/
1. chmod +x create_udev_rules
1. rosrun ancube_bringup 



## Opearating

1.