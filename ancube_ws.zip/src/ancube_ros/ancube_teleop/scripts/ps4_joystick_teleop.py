#!/usr/bin/env python
# Author: Liews Wuttipat

import rospy
import actionlib
import ds4_driver.msg
import geometry_msgs.msg
import nav_msgs.msg
import sensor_msgs.msg
import topic_tools.srv
import control_msgs.msg
import trajectory_msgs.msg


def integrate(desired, present, max_rate, dt):
    if desired > present:
        return min(desired, present+max_rate*dt)
    else:
        return max(desired, present-max_rate*dt)


class TeleopComponent(object):
    def __init__(self):
        self._active = False

    def update(self, joy, state):
        raise NotImplementedError()

    def publish(self, dt):
        raise NotImplementedError()

    def start(self):
        raise NotImplementedError()

    def stop(self):
        raise NotImplementedError()


class BaseTeleop(TeleopComponent):
    def __init__(self):
        super(BaseTeleop, self).__init__()

        # Button mapping
        self._deadman = rospy.get_param("~button_deadman", "button_r2")
        self._axis_x = rospy.get_param("~axis_x", "axis_right_y")
        self._axis_w = rospy.get_param("~axis_w", "axis_left_x")

        # Base limits
        self._max_vel_x = rospy.get_param("~max_vel_x", 1.0)
        self._min_vel_x = rospy.get_param("~min_vel_x", -0.5)
        self._max_vel_w = rospy.get_param("~max_vel_w", 3.0)
        self._max_acc_x = rospy.get_param("~max_acc_x", 1.0)
        self._max_acc_w = rospy.get_param("~max_acc_w", 3.0)

        # Maximum windup of acceleration ramping
        self._max_windup_time = rospy.get_param("~max_windup_time", 0.25)

        # Mux for overriding navigation, etc.
        self._use_mux = rospy.get_param("~use_mux", True)
        if self._use_mux:
            self._mux = rospy.ServiceProxy(
                '/cmd_vel_mux/select', topic_tools.srv.MuxSelect)
            self._prev_mux_topic = "/cmd_vel"

        self._cmd_vel_pub = rospy.Publisher(
            "/teleop/cmd_vel", geometry_msgs.msg.Twist, queue_size=10)
        rospy.Subscriber("/odom", nav_msgs.msg.Odometry,
                         self.odomCallback, queue_size=10)

        self._desired = geometry_msgs.msg.Twist()
        self._last = geometry_msgs.msg.Twist()
        self._odom = nav_msgs.msg.Odometry()

        self._attrs = []
        for attr in ds4_driver.msg.Status.__slots__:
            if attr.startswith('axis_') or attr.startswith('button_'):
                self._attrs.append(attr)

    def update(self, joy, state):
        input_vals = {}
        for attr in self._attrs:
            input_vals[attr] = getattr(joy, attr)

        deadman_pressed = input_vals[self._deadman]
        if not deadman_pressed:
            self.stop()
            return False

        self.start()
        if input_vals[self._axis_x] > 0.0:
            self._desired.linear.x = input_vals[self._axis_x] * self._max_vel_x
        else:
            self._desired.linear.x = input_vals[self._axis_x] * - \
                self._min_vel_x

        self._desired.angular.z = input_vals[self._axis_w] * self._max_vel_w

        return True

    def publish(self, dt):
        if self._active:
            # if self._last.linear.x >= self._odom.twist.twist.linear.x:
            #     self._last.linear.x = min(
            #         self._last.linear.x, self._odom.twist.twist.linear.x + self._max_acc_x * self._max_windup_time)
            # else:
            #     self._last.linear.x = max(
            #         self._last.linear.x, self._odom.twist.twist.linear.x - self._max_acc_x * self._max_windup_time)

            # if self._last.angular.z >= self._odom.twist.twist.angular.z:
            #     self._last.angular.z = min(
            #         self._last.angular.z, self._odom.twist.twist.angular.z + self._max_acc_w * self._max_windup_time)
            # else:
            #     self._last.angular.z = max(
            #         self._last.angular.z, self._odom.twist.twist.angular.z - self._max_acc_w * self._max_windup_time)

            self._last.linear.x = integrate(
                self._desired.linear.x, self._last.linear.x, self._max_acc_x, dt.to_sec())
            self._last.angular.z = integrate(
                self._desired.angular.z, self._last.angular.z, self._max_acc_w, dt.to_sec())
            rospy.logwarn("{:.3f}/{:.3f}, {:.3f}/{:.3f}".format(
                self._last.linear.x, self._odom.twist.twist.linear.x, self._last.angular.z, self._odom.twist.twist.angular.z))
            self._cmd_vel_pub.publish(self._last)

    def start(self):
        if not self._active and self._use_mux:
            try:
                resp = self._mux.call(self._cmd_vel_pub.name)
                self._prev_mux_topic = resp.prev_topic
            except rospy.ServiceException as e:
                rospy.logerr(e)
                rospy.logerr("Unable to switch mux")
        self._active = True
        return self._active

    def stop(self):
        self._last = self._desired = geometry_msgs.msg.Twist()
        self._cmd_vel_pub.publish(self._last)
        if self._active and self._use_mux:
            try:
                resp = self._mux.call(self._prev_mux_topic)
            except rospy.ServiceException as e:
                rospy.logerr(e)
                rospy.logerr("Unable to switch mux")
                return self._active
        self._active = False
        return self._active

    def odomCallback(self, odom):
        self._odom = odom


class FollowTeleop(TeleopComponent):
    def __init__(self):
        super(FollowTeleop, self).__init__()
        # Button mapping
        self._deadman = rospy.get_param("~button_deadman", "button_r2")
        self._inc_button = rospy.get_param("~button_increase", "button_l1")
        self._dec_button = rospy.get_param("~button_decrease", "button_l2")

        # Joint limits
        self._min_position = rospy.get_param("~min_position", 0.0)
        self._max_position = rospy.get_param("~max_position", 0.5)
        self._max_velocity = rospy.get_param("~max_velocity", 0.075)
        self._max_acceleration = rospy.get_param("~max_accel", 0.25)

        self._inhibit = rospy.get_param("~inhibit", False)
        self._joint_name = rospy.get_param(
            "~joint_name", default="fork_lift_joint")
        self._action_name = rospy.get_param(
            "~action_name", default="lift_controller/follow_joint_trajectory")

        self._client = actionlib.SimpleActionClient(
            self._action_name, control_msgs.msg.FollowJointTrajectoryAction)
        if not self._client.wait_for_server(rospy.Duration(2.0)):
            rospy.logerr("{} may not be connected.".format(self._action_name))

        self._attrs = []
        for attr in ds4_driver.msg.Status.__slots__:
            if attr.startswith('axis_') or attr.startswith('button_'):
                self._attrs.append(attr)

        self._actual_position = 0.0
        self._desired_velocity = 0.0
        self._last_velocity = 0.0

    def update(self, joy, state):
        input_vals = {}
        for attr in self._attrs:
            input_vals[attr] = getattr(joy, attr)

        deadman_pressed = input_vals[self._deadman]
        if not deadman_pressed:
            self.stop()
            if self._joint_name in state.name:
                idx = state.name.index(self._joint_name)
                self._actual_position = state.position[idx]
            return False

        if input_vals[self._inc_button]:
            self._desired_velocity = self._max_velocity
            self.start()
        elif input_vals[self._dec_button]:
            self._desired_velocity = -self._max_velocity
            self.start()
        else:
            self._desired_velocity = 0.0
        return True
        return self._inhibit

    def publish(self, dt):
        if self._active:
            step = 0.25
            vel = integrate(self._desired_velocity,
                            self._last_velocity, self._max_acceleration, step)
            travel = step * (vel + self._last_velocity) / 2.0
            pos = max(self._min_position, min(
                self._max_position, self._actual_position + travel))

            goal = control_msgs.msg.FollowJointTrajectoryGoal()
            goal.trajectory.joint_names.append(self._joint_name)
            p = trajectory_msgs.msg.JointTrajectoryPoint()
            p.positions.append(pos)
            p.velocities.append(vel)
            p.time_from_start = rospy.Duration(step)
            goal.trajectory.points.append(p)
            goal.goal_time_tolerance = rospy.Duration(0.0)
            self._client.send_goal(goal)

            vel = integrate(self._desired_velocity, self._last_velocity,
                            self._max_acceleration, dt.to_sec())
            travel = dt.to_sec() * (vel+self._last_velocity)/2.0
            self._actual_position = max(self._min_position, min(
                self._max_position, self._actual_position+travel))
            self._last_velocity = vel

    def stop(self):
        self._active = False
        self._last_velocity = 0.0
        return self._active


class TeleopNode:
    def __init__(self):
        rospy.init_node("teleop_node")
        rospy.loginfo("Starting TeleopNode as teleop_node.")

        self._components = [BaseTeleop(), FollowTeleop()]
        self._last_update = rospy.Time.now()
        self._state_msg = sensor_msgs.msg.JointState()

        rospy.Subscriber("joy/status", ds4_driver.msg.Status,
                         self.__joyCallback, queue_size=1)
        rospy.Subscriber("joint_states", sensor_msgs.msg.JointState,
                         self.__stateCallback, queue_size=10)

    def publish(self, dt):
        if rospy.Time.now() - self._last_update > rospy.Duration(0.25):
            for c in self._components:
                c.stop()
        else:
            for c in self._components:
                c.publish(dt)

    def __joyCallback(self, msg):
        ok = True
        for c in self._components:
            if ok:
                ok &= not c.update(msg, self._state_msg)
            else:
                c.stop()
        self._last_update = rospy.Time.now()

    def __stateCallback(self, msg):
        # Update each joint based on message
        for i, msg_j in enumerate(msg.name):
            if msg_j in self._state_msg.name:
                idx = self._state_msg.name.index(msg_j)
                self._state_msg.position[idx] = msg.position[i]
                self._state_msg.velocity[idx] = msg.velocity[i]
                self._state_msg.effort[idx] = msg.effort[i]
            else:
                # New joint
                self._state_msg.name.append(msg.name[i])
                self._state_msg.position.append(msg.position[i])
                self._state_msg.velocity.append(msg.velocity[i])
                self._state_msg.effort.append(msg.effort[i])


if __name__ == "__main__":
    teleop = TeleopNode()
    # rospy.spin()
    rate = rospy.Rate(30.0)
    while not rospy.is_shutdown():
        teleop.publish(rospy.Duration(1.0/30.0))
        rate.sleep()
