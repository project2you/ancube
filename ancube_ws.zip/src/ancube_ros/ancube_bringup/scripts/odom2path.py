#!/usr/bin/env python
import rospy

import nav_msgs.msg
import geometry_msgs.msg


class Odom2PathNode:
    def __init__(self):
        rospy.init_node("odom2path_node")
        rospy.loginfo("Starting Odom2PathNode as odom2path_node.")

        self._path_pub = rospy.Publisher(
            "path", nav_msgs.msg.Path, queue_size=10)
        rospy.Subscriber("odom", nav_msgs.msg.Odometry, self._odom_cb)
        self._path_msg = nav_msgs.msg.Path()

    def _odom_cb(self, msg):
        curr_pose = geometry_msgs.msg.PoseStamped()
        curr_pose.header = msg.header
        curr_pose.pose = msg.pose.pose
        self._path_msg.header = msg.header
        self._path_msg.poses.append(curr_pose)
        self._path_pub.publish(self._path_msg)


if __name__ == "__main__":
    odom2path_node = Odom2PathNode()
    rospy.spin()
